from plot_all_figures import plot_figS3
plot_figS3()
