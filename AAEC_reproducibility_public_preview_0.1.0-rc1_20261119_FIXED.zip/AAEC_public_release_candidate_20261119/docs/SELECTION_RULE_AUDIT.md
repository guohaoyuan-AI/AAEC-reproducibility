# AAEC v3.1 — Step 1C: 选择规则与验证约束专项审计

**日期：**2026-11-13  
**稿件：**NEUCOM-D-26-16880  
**校对对象：**已完成 1B 的 LaTeX 工作副本；原投稿15个 method–seed 设置的75条候选级记录；C60 B/C 十个独立训练运行的验证预测 NPZ 与冻结JSON；C60正式验证脚本 `aaec_r23_bc_eval.py`。  
**不在本轮范围：**训练充分性、数据划分/预处理的全面复核（1D）；所有图表的全量复算（1E）；整稿英文（1F）；最终全PDF排版审查（Step 3）；九点网格GPU实验。

## 1. 结论与分级

**结果：对可独立重算的选择，未发现违反正式 AAEC 规则的数值错误。** 原投稿15/15与归档候选级选择一致；C60五个正式C臂与对应逐图验证预测和冻结选择记录一致。进一步校核了另外五个B臂的验证预测（共10个B/C checkpoint），结果亦与其冻结记录一致。**这些结论不等于已重新执行或认证丢失的原始历史训练runner。**

| 项目 | 当前结论 | 证据等级 |
|---|---|---|
| 正式grid | `{0.2,0.4,0.6,0.8,1.0}`，每个checkpoint独立枚举五个候选，两种clean视图 | 公式和C60源码可核验 |
| grid-best reference | Bicubic与Bilinear各取自身在五点候选上的最大验证准确率 | 原15聚合、C60逐图复核 |
| 联合可行 | 两视图**都**满足相对各自grid-best的ε阈值；不对视图平均 | 原15聚合、C60逐图复核 |
| ε单位 | 0.5pp / 0.3pp，比例准确率代码对应0.005/0.003 | C60源码和独立计数测试 |
| 选择策略 | 最小共同可行α，空集才fallback至1.0 | C60源码和边界单元测试 |
| 原稿15组 | 主ε下15/15一致；严格ε下已核对每组α；两种ε下均没有empty-set fallback | 候选级聚合记录（无原逐图预测） |
| C60 C臂5组 | 主ε下选择 `LoRA .6, DoRA .6, Adapter .8, SSF .8, LN .8`，5/5一致 | 存档NPZ + frozen selection JSON + SHA256 |
| C60 B臂5组 | `LoRA .8, DoRA .8, Adapter .8, SSF 1.0, LN .8`，5/5一致；**B臂不进入C60正式正文结果** | 存档NPZ + frozen selection JSON |
| test信息排除 | C60脚本先生成validation预测与selection_frozen，之后检查冻结选择再运行test；10份归档文件mtime符合 `validation <= selection < test` | 源码/冻结记录/归档时间，不能替代完整外部操作审计 |
| 旧selector影响 | 历史旧runner存在其他选择准则；不能将它们的日志标签自动映射为正式AAEC规则 | 1B恢复代码审计；保留历史来源限制 |
| 原15选点历史执行链 | 可重新计算，但原runner、旧checkpoint及历史调用时间线无法全数恢复 | **未完全认证** |
| Night7 | 只有日志级摘要，缺逐图正式验证预测；无法独立完整认证选择过程 | **证据不足，保持限制** |
| 九点密度 | 无GPU，仍未运行；不得推断 | **待补充** |

## 2. 形式化判据与边界

令两个视图的验证准确率为 `a[alpha][view]`（以百分点表示），`R[view]=max_alpha a[alpha][view]`，联合可行当且仅当对两个视图都满足 `R[view]-a[alpha][view] <= epsilon_pp`。候选集按0.2到1.0从小到大枚举，选择首个可行点；若完全无可行点，返回1.0并记录 `fallback=True`。该fallback自身**不保证**满足两视图约束。

特别区分：

- `selected_alpha=1.0` 与 `fallback=True` 并不等价。α1可以是非空可行集的最小成员。原稿严格ε下Adapter seed42选到1.0，但它是可行点，而**不是**空集fallback；C60部分B/C严格设置也是如此。
- 0.5pp 对5000张图意味着最多损失25个正确样本；0.3pp 意味着最多15个，严格的准确率边界应该用未舍入计数判定，而不是先四舍五入为两位小数。
- 违规统计为两个clean视图**任一**视图超出阈值，即 OR 判定；原稿9/15来自两个视图**同时**违规的AND口径。对固定0.6与Nearest oracle应为11/15。此修正已由此前工作版实施，1C再次确认；不替换原稿候选准确率。
- `α=0`不属于正式候选集；它可用于实现锚点单元测试，但不能悄悄加入正式选择网格。

## 3. 数据与实现映射

### 3.1 原投稿主15组

数据：`03_R2_1/AAEC_original_15seed_5alpha_reconstructed.csv` 与 `AAEC_original_15seed_aaec_vs_fixed08_verified.csv`。每组5个α、两种验证视图，累计75条候选行；候选行在组内具有一致checkpoint哈希标识。按准确率反推每5000张验证图像的正确数，基于整数计数独立计算0.5/0.3pp联合可行集、最小α及empty-set fallback；逐行与归档正式选择比较，15/15一致。该CSV描述为**从保存的候选级聚合表恢复**，不含可重新抽样的逐图原始预测。不能把它描述为一次重跑原训练checkpoint。

### 3.2 C60运行

数据：`04_R2_3/AAEC_R23_BC_FORMAL_EVAL_EVIDENCE_20261111.tar.gz` 的每个 `validation_predictions.npz`（数组含5000 image IDs、labels、5×2×5000的predictions）及 `selection_frozen.json`；对照 `08_REPRODUCIBLE_TABLES/R2-3_C60_selection_frozen_summary.csv`。独立程序不读取held-out predictions用于选α，并核对预测NPZ SHA256、五点α顺序、两视图ID对齐、冻结选择、checkpoint标识。10份B/C都一致；正式C臂5份与冻结汇总的checkpoint SHA及NPZ SHA也吻合。

C60正式脚本 `AAEC_R23_BC_FORMAL_EVAL_KIT_20261111.zip/aaec_r23_bc_eval.py`：

- 第103–116行定义 `select_alpha`：各视图取max，以 `eps/100` 设置阈值，通过两视图逐点AND构造可行集合，取排序后首个可行点或末端1.0。
- 第345–385行先生成并保存`validation_predictions.npz`及`selection_frozen.json`。
- 第385–403行通过验证原始标签、图像ID、alphas、views、checkpoint及预测SHA核对冻结记录，并检查不使用Nearest/corruption的声明字段。
- 第425行之后的held-out test流程使用冻结selection，并复核选择状态与test产物的SHA绑定。

归档mtime仅能支持其保存顺序；不能由mtime单独证明运行中没有预先查看测试指标。源码分阶段隔离与冻结SHA提供更强但仍有限的支持。

### 3.3 旧selector与扩展

1B审计已记录foundation版本的 `run_fr_peft.py`、`run_adapter_adi_cifar100.py` 使用“最大Bilinear并约束Bicubic”的旧规则，扩展runner包含其他探索规则。它们不是本文正式使用的“分别取两视图grid-best、最小联合可行α”。当丢失原始runtime时，不能仅凭旧选择器的存在就宣布正式数据错误，也不能因α数值巧合相同便认证历史实际选择调用。

本轮把Method与Experimental Setup中的**不加限定的全部历史选择认证口吻**收紧为：论文定义的正式规则不访问held-out指标；原主15和C60可从保存验证记录按该规则重新计算；其他扩展数据保留Supplementary Table S6的来源限制。

## 4. 本轮论文修订（均为证据边界澄清）

| 位置 | 改动性质 | 是否改变方法/数值 |
|---|---|---|
| `03_method.tex` / Operational procedure | 将“全部历史结果都按canonical规则重新认证”改为明确的正式规则和历史来源边界 | 否 |
| `04_experimental_setup.tex` / Canonical final-checkpoint selection | 准确表述“原15组从聚合候选复算、C60从逐图预测复算”，指出其他扩展的限制 | 否 |
| `supplementary_material.tex` / S6 | 增加独立选择审计的证据范围、C60冻结程序与 `α=1 != fallback` 的澄清 | 否 |

**没有**修改正式α网格、epsilon、原稿主结果、C60评估数值、Night7日志结果、Figure 1/2或Response Letter的结论；**没有**补造九点实验或使用Nearest/CIFAR-100-C重新选系数。

## 5. 独立测试与交付审计

- `recheck_selection_independent_20261113.py`：独立计数版算法（不引用正式runner中的选择函数），覆盖原15组、C60 B/C十组、两种容差、fallback边界，以及所有NPZ冻结摘要一致性；运行PASS。
- `evidence_1C/ORIGINAL_15_SELECTION_RECOMPUTED.csv`：15组全部选点与可行集。
- `evidence_1C/C60_BC_10_SELECTION_RECOMPUTED.csv`：B/C十组逐图选点、文件SHA及可行集。
- `evidence_1C/C60_BC_ARCHIVE_TIMESTAMP_CHECK.csv`：十个归档运行的validation、freeze、test文件时间顺序，全部满足顺序。
- `evidence_1C/SUMMARY.json`：可机读审计总览。
- `AAEC_STEP1C_REPRODUCIBILITY_20261113.zip`：独立打包的输入候选CSV、C60验证NPZ与冻结JSON及可直接运行的纯CPU复算脚本（无需checkpoint、GPU）。

LaTeX主论文与Supplement均已通过本地pdflatex编译两次（41页 / 22页）；未发现未解析引用。存在Supplement旧有的Overfull hbox警告，应保留至最终Step 3排版检查。本阶段只检查修改所涉及页面，并不宣称已完成逐页全PDF提交审计。

## 6. 1C结论与转入1D的条件

**1C在可恢复选择证据范围内完成。** 正式规则、原主15选点、C60五点选点均可复算；代码中没有发现已验证C60决策调用读取Nearest/corruption作为选择特征；历史旧selector影响只可通过候选级独立复算排除其对当前15格统计表的直接污染，不能证明丢失的历史执行字节序列；Night7和其他扩展的运行级规则认证仍有证据边界。九点网格按作者要求继续延期。

下一轮仅做1D训练协议/预处理/seed/checkpoint与数据划分审计，不把新训练endpoint用于替换原投稿主实验。
