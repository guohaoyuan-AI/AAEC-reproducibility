# C60 revision evidence

This folder contains the post-submission Reviewer-2 seed-42 B/C cohort.
B and C are separate training arms (15 and 60 epochs respectively) across
five PEFT families. `formal_evaluation/` contains validation/test and
predeclared corruption prediction arrays with frozen selection metadata.
`dense_grid_validation/` contains validation-only 9-point sensitivity
arrays. `training_metadata/` contains run configs, epoch metadata, logs,
and PASS manifests. No model checkpoints or weights are included.
