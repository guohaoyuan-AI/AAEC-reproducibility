# Code provenance and public distribution scope

The public preview includes two categories of original AAEC-authored software:

- `src/aaec/selection.py`: portable reference implementation derived from the
  archived C60 formal evaluator; unit-tested here, but not a byte-identical
  recovery of the lost original training runner.
- `code/figure_generation/`: figure-generation scripts and helpers used with
  the frozen figure-data CSVs.

The recovered `tasfd` foundation/runtime source tree and C60 training/evaluation
runner snapshots were present in the internal candidate but have been excluded
from this public preview. Their historical origins and SHA-256 mappings are
documented in the private project audit records; complete upstream license
and copyright notices were not established to a level suitable for blanket
MIT relicensing. They may be added in a later release after file-level review.

This repository does not claim exact historical runtime source certification
for every original ViT-B training run. Formula-to-recovered-implementation
correspondence and structural tests are documented in the manuscript audit,
with explicit limitations.
