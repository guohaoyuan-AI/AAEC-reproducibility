# Original primary-cohort data

These files originate from the frozen WP8-A master-data package (2026-07-28)
and associated recovered 15-cell candidate-level records. The master package
records 3,910 long-format rows and 54 cross-table checks with zero failures.
Accuracy is stored as a fraction; gain/drop metrics use percentage points.
The recovered candidate-level records are aggregate records, not raw
per-image predictions. The original trained checkpoints are not included.
