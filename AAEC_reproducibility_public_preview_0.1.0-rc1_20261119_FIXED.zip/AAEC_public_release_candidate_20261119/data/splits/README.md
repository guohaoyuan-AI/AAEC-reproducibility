# Split indices

The NumPy files in `cifar100_seed42/` are integer indices for the 45,000
training and 5,000 validation membership used by the later C60 seed-42
revision cohort. They contain no images or model parameters.
