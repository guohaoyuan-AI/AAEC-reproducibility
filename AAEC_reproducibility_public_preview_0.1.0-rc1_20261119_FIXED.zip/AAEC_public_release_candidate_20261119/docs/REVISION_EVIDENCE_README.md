# Revision evidence included for numerical traceability

The CSVs were derived in the independent 2026-11-12 audit from original 15-cell candidate-level records and C60 paired per-image prediction archives. The associated Python recomputation scripts are included in the full revision package.

Figure 4 and its regeneration script use the independently audited **either-view (OR)** violation criterion. The legacy frozen policy summary counted **both-view (AND)** violations for fixed alpha=0.6 and the Nearest oracle, producing 9/15 instead of 11/15.

No nine-point validation outcomes exist. Night7 per-image post-training predictions are not present.
