from plot_all_figures import plot_fig6
plot_fig6()
