from plot_all_figures import plot_figS1
plot_figS1()
