# AAEC v3.1 — Step 1B: Five-Family PEFT Implementation Correspondence Audit

**Date:** 2026-11-12  
**Manuscript:** NEUCOM-D-26-16880  
**Scope:** LoRA, DoRA, Adapter, SSF, and LayerNorm tuning parameterization; injected modules; trainable/frozen parameter scope; method-native anchor; alpha application; parameter-count correspondence; recovered-code provenance.  
**Explicit exclusions:** coefficient-selection policy and validation/test isolation are reserved for Step 1C; training/data protocol is reserved for Step 1D; whole-document PDF inspection is reserved for Step 1E/Step 3.

## 1. Executive finding

No algebraic mismatch was found between the five method-specific AAEC equations in the revised Method section and the corresponding recovered implementation functions examined in this audit. The recovered code also reproduces the parameter counts reported in Supplementary Table S8.

However, **the exact historical runtime source cannot be certified for every original ViT-B training run**. The original submission source ZIP contains LaTeX, bibliography, and figure assets but no Python implementation. Recovered LoRA/DoRA and Adapter implementation files are present in the foundation snapshot; the recovered SSF/LayerNorm implementation file is from a later ADI-v2 extension snapshot. The source archive does not provide a complete per-run source-hash-to-original-checkpoint mapping for all five original ViT-B jobs. Accordingly, this audit establishes formula-to-recovered-code correspondence and current structural tests, not byte-identical historical runtime reproduction.

The author's evidence hierarchy remains unchanged: original-submission numerical records remain the primary evidence. C60 and Night7 remain separate post-submission evidence and are not substituted for original checkpoints or pooled into the original cohort.

## 2. Materials and provenance checked

### 2.1 Manuscript materials

- Original submission package: `AAEC_Neurocomputing_Final_Submission_Source.zip` (44 files; `.tex`, `.bib`, and figure assets; no `.py`, `.yaml`, or `.sh` training source files).
- Revised manuscript: `03_method.tex` and `tableS8_implementation_and_diagnostics.tex`.
- Original and revised Table S8 implementation descriptions.

### 2.2 Recovered implementation sources

| Component | Recovered file | SHA-256 | Source classification |
|---|---|---|---|
| LoRA/DoRA modules | `01_FOUNDATION_UNMODIFIED/src/tasfd/models/peft/lora_dora.py` | `94742c742e33a9032dc5f46b9a4450a7ea6d13ede945b7db3ad6ba3358dba111` | Foundation snapshot; one indexed version |
| LoRA/DoRA runner | `01_FOUNDATION_UNMODIFIED/src/tasfd/engine/run_fr_peft.py` | `1448faca85e3d65bf99f61cecd0f0f20211ec982f5eccef5b0d8d1ea9c4673d8` | Foundation runner variant |
| Later FR-PEFT runner | `02_LATER_FILES_BY_ORIGIN/AUTODL_EXP4/O/src/tasfd/engine/run_fr_peft.py` | `436d72da604e3f11791ae3c0fac3c96e5f94c6cf88b559a96a6675ff58ca9f18` | Later runner variant; diff adds dataset-loader imports/dispatch for Tiny-ImageNet/ImageNet-100 |
| Adapter runner | `01_FOUNDATION_UNMODIFIED/tools/run_adapter_adi_cifar100.py` | `2daf51a2ca148fdc3be2ad8e7529d37c9799ccfa0b8d5eeac22ada0956d8e647` | Foundation snapshot; same file hash also indexed in EXPANSION |
| Adapter extension runner | `02_LATER_FILES_BY_ORIGIN/VITS16_C100C/O/tools/run_adapter_adi_v2_any_dataset.py` | `065117a8549a88612e20fec2ab996a6822e9a74e425c5b121fd4c9c6de2e2c51` | Later extension snapshot; core Adapter functions match foundation runner |
| SSF/LayerNorm runner | `02_LATER_FILES_BY_ORIGIN/VITS16_C100C/O/tools/run_anchor_peft_adi_v2_any_dataset.py` | `3f7b38727ce28bc572f4b1415fd9ca424eb50b254cfe4293dbe9b21fdb8a3254` | Later ADI-v2 extension snapshot; same hash indexed across EVIDENCE/TRAIN12/AUTODL_EXP4/VITS16_C100C |

The source-version index reports a conflict for `src/tasfd/engine/run_fr_peft.py`; inspection of the two variants found only added dataset-loader imports and Tiny-ImageNet/ImageNet-100 dispatch branches. The `lora_dora.py` module itself has one indexed recovered hash.

The file `src/tasfd/models/adapters/ta_sfd_adapter.py` contains project-specific TORA/spectral adapter classes. It is **not** imported by the recovered `run_adapter_adi_cifar100.py` PEFT baseline and must not be cited as the implementation of the paper's residual bottleneck Adapter.

### 2.3 Five-method preflight evidence

The recovered `aaec_peft_five_method_preflight_20261108.py` imports:

- LoRA/DoRA from `tasfd.models.peft`;
- Adapter from `run_adapter_adi_v2_any_dataset.py`;
- SSF and LayerNorm tuning from `run_anchor_peft_adi_v2_any_dataset.py`.

The handoff `STATUS_AND_EVIDENCE.md` records that the ViT-B five-method injection/parameter audit passed with the counts reproduced below. The raw `peft_5_methods_audit.json` output is not present in the available local handoff tree. This audit therefore does not present that reported AutoDL PASS as a locally re-read raw report.

## 3. Method-by-method correspondence

### 3.1 LoRA

**Recovered implementation:** `lora_dora.py`, `LoRALinear` lines 31–70; injection and trainability lines 181–270.

- Target modules: fused attention `attn.qkv` and attention output projection `attn.proj`, in all 12 transformer blocks (24 wrapped linear layers).
- Rank: 16; method scaling: 16; implementation scaling is `alpha/rank = 1` for the reported configuration.
- Dropout: 0 in the formal configuration.
- Trainable: low-rank factors `A` and `B`, plus the classifier head.
- Frozen: pretrained base projection weights and biases.
- Native anchor: pretrained base weight `W0` with zero low-rank residual.
- Recovered forward: `base(x) + delta_scale * (alpha/rank) * B(A(x))`; `delta_weight()` returns `(alpha/rank) * B @ A`.

**Assessment:** matches `Delta W_LoRA = sBA` and `W_alpha = W0 + alpha Delta W_LoRA`. The base bias is retained unchanged. The revised manuscript now states this explicitly.

### 3.2 DoRA

**Recovered implementation:** `lora_dora.py`, `DoRALinear` lines 73–164; injection and trainability lines 181–270.

- Same 24 attention projections, rank 16, method scaling 16, and zero dropout.
- Trainable: low-rank direction factors `A` and `B`, per-output-row magnitude vector `m`, and classifier head.
- Frozen: pretrained base weights and biases; base row magnitudes are retained as a buffer for initialization/reference.
- Direction is formed as `W0 + (alpha/rank) * B @ A`; row norms are taken over the input-feature dimension (`dim=1` for PyTorch `[out,in]` weights).
- Effective DoRA weight is row-normalized direction multiplied by the learned per-output-row magnitude.
- Intermediate AAEC states are formed as `W0 + alpha * (W_DoRA - W0)`, with the original base bias unchanged.
- The recovered code rejects nonzero DoRA dropout to preserve the exact dense effective-weight representation; the formal configuration uses dropout 0.

**Assessment:** matches the revised complete-effective-weight equation and displacement interpolation. It does not merely scale the directional low-rank branch while retaining full-strength magnitude.

### 3.3 Adapter

**Recovered implementation:** `run_adapter_adi_cifar100.py`, `ResidualAdapter` lines 102–152 and `inject_residual_adapters` lines 171–239; matching core functions also occur in `run_adapter_adi_v2_any_dataset.py`.

- One residual bottleneck branch is attached after each of the 12 transformer blocks.
- Each branch contains a trainable input LayerNorm, `d -> 32` down-projection, GELU, and `32 -> d` up-projection; biases are present and dropout is 0.
- Down-projection weights are initialized from a normal distribution with standard deviation `1e-3`; down bias is zero; up-projection weights and bias are zero-initialized.
- The entire Adapter object is trainable, including its input LayerNorm affine parameters; the pretrained transformer block remains frozen. The classifier head is trainable.
- Alpha is applied to the output residual response: `block_output + alpha * Adapter(block_output)`.
- At alpha 0, the adapter branch is absent; at alpha 1, the standard trained residual branch is active.

**Assessment:** matches the manuscript's residual-response equation. This is a **specific post-block residual bottleneck Adapter variant**, not an exact reproduction of every canonical Houlsby or AdaptFormer insertion layout. The revised Method now identifies it as a post-block variant; Table S8 specifies its structure and initialization.

### 3.4 SSF

**Recovered implementation:** `run_anchor_peft_adi_v2_any_dataset.py`, `SSFWrapper` lines 78–96, `inject_ssf` lines 116–141, `mark_trainable` lines 266–287.

- One wrapper is inserted after each block's `norm1` and `norm2`: 24 wrappers for 12 blocks.
- The wrapper first applies the original LayerNorm, then applies a feature-wise scale and shift.
- SSF gamma is initialized to ones and beta to zeros, giving the identity modulation anchor.
- Only SSF gamma/beta and the classifier head are trainable. The wrapped base LayerNorm affine weights/biases are frozen.
- The final backbone normalization is excluded in the recovered configuration.
- Alpha is applied as `gamma_eff = 1 + alpha*(gamma-1)` and `beta_eff = alpha*beta`.

**Assessment:** matches the SSF equations. The revised Method now identifies `h` as the output of the frozen `norm1`/`norm2` module and clarifies that the underlying LayerNorm affine parameters are not the SSF trainables.

**Provenance limitation:** this recovered SSF implementation file is from a later ADI-v2 extension snapshot, not the unmodified foundation directory. It is consistent with the original paper's Table S8 placement and parameter count, but the available archive does not prove that this exact byte sequence was the runtime used for every original ViT-B SSF checkpoint.

### 3.5 LayerNorm tuning

**Recovered implementation:** `run_anchor_peft_adi_v2_any_dataset.py`, `mark_layernorm_tuning` lines 165–185, `snapshot_layernorm_tuned` lines 188–196, `set_layernorm_alpha` lines 199–212, `mark_trainable` lines 266–287, checkpoint save lines 487–503.

- All `nn.LayerNorm` modules are collected: `norm1` and `norm2` in each of 12 blocks plus the final backbone LayerNorm (25 modules in the ViT-B/16 configuration).
- The pretrained weight and bias tensors are cloned before training as the anchor.
- All LayerNorm affine weights and biases are trainable, together with the classifier head; all other backbone parameters are frozen.
- The final tuned affine values are snapshotted after training and saved with the checkpoint.
- `set_layernorm_alpha` restores `theta0 + alpha*(theta1-theta0)` from the stored anchor and tuned snapshots, rather than accumulating successive interpolations.

**Assessment:** matches the manuscript's affine-displacement equation. The revised Method now defines `theta_LN` as the collection over all 25 modules.

**Provenance limitation:** as with SSF, the recovered implementation is from a later ADI-v2 extension snapshot. Exact byte-identical historical runtime mapping to all original ViT-B LN-tuning runs is unavailable.

## 4. Trainable-parameter count reconciliation

All counts include the 76,900-parameter classifier head unless explicitly separated.

| Method | PEFT-object parameter calculation | PEFT object | Head | Total trainable |
|---|---|---:|---:|---:|
| LoRA | 12 blocks × [(768+2304)×16 + (768+768)×16] | 884,736 | 76,900 | **961,636** |
| DoRA | LoRA factors 884,736 + 12 × (2304+768) magnitude entries | 921,600 | 76,900 | **998,500** |
| Adapter | 12 × [LN (2×768) + down (768×32+32) + up (32×768+768)] | 617,856 | 76,900 | **694,756** |
| SSF | 24 × (gamma 768 + beta 768) | 36,864 | 76,900 | **113,764** |
| LayerNorm tuning | 25 × (weight 768 + bias 768) | 38,400 | 76,900 | **115,300** |

The independently reproduced totals match the values in Table S8 and the expected values in the recovered five-method preflight script.

## 5. Audit-time implementation tests

A CPU test script imported the recovered method classes/functions and built a synthetic 12-block ViT-shaped module with `d=768`, fused `qkv` output dimension 2304, attention projection dimension 768, and a 100-class head. The tests checked trainable/frozen scopes, injection counts, parameter totals, and alpha endpoint/interpolation behavior.

| Test | Result |
|---|---|
| LoRA alpha 0 recovers base linear output; alpha 1 applies full scaled low-rank update | PASS |
| DoRA alpha 0 recovers base linear output; alpha 1 reconstructs effective DoRA; alpha 0.4 equals complete weight-displacement interpolation | PASS |
| Adapter alpha 0 equals original block output; alpha 1 equals block output plus the Adapter response | PASS |
| SSF alpha 0 returns the frozen LayerNorm output; alpha 1 applies trained gamma/beta; base LayerNorm remains frozen | PASS |
| LayerNorm tuning alpha 0 restores pretrained affine tensors; alpha 1 restores tuned tensors; alpha 0.5 equals their midpoint | PASS |
| All five trainable-parameter totals and module counts | PASS |

**Environment and limits:** the audit used PyTorch `2.10.0+cpu`. `timm` was not installed in this container, so the independent test used a synthetic ViT-shaped module rather than the original pretrained timm model. It did not load historical checkpoints, run GPU training, or establish original run-to-code identity. The handoff separately records a successful AutoDL five-method parameter/injection preflight; its raw JSON result was not available for re-reading here.

## 6. Issues found and corrections applied

| ID | Issue | Severity | Correction |
|---|---|---|---|
| IMPL-01 | Adapter could be read as a canonical Houlsby/AdaptFormer implementation, although the recovered implementation is specifically post-block | Moderate wording ambiguity | Method now names it a post-block residual bottleneck variant and describes its module sequence; Table S8 specifies initialization |
| IMPL-02 | LoRA wrapped linear-layer bias handling was implicit | Minor technical omission | Method now states wrapped base biases remain frozen and unchanged |
| IMPL-03 | Adapter input LayerNorm trainability and initialization details were not explicit enough | Moderate reproducibility ambiguity | Method and Table S8 now state the input LayerNorm is part of the trainable Adapter object; initialization is specified by projection |
| IMPL-04 | SSF `h` and the status of the underlying LayerNorm affine parameters were underspecified | Moderate technical ambiguity | Method now locates SSF after `norm1`/`norm2` and states their base affine parameters remain frozen |
| IMPL-05 | LayerNorm tuning did not state the full set of modules represented by `theta_LN` | Moderate notation ambiguity | Method now defines the 25-module collection and trainable affine scope |
| IMPL-06 | Recovered code provenance could be mistaken for exact historical runtime proof | Major traceability limitation | Table S8 now explicitly discloses the later ADI-v2 origin of recovered SSF/LN code and absence of a complete five-run source-hash mapping |

No experimental result, original checkpoint summary, seed-level main table, or original-submission data value was changed in Step 1B.

## 7. Items carried forward to Step 1C

1. `run_fr_peft.py` and `run_adapter_adi_cifar100.py` contain legacy `max-Bilinear-with-Bicubic-guard` selection logic.
2. `run_anchor_peft_adi_v2_any_dataset.py` contains several diagnostic selection rules; it is not itself proof that the canonical v3.1 joint per-view grid-best selector was used for a given run.
3. The canonical v3.1 rule is the per-view grid-best reference, joint admissibility within epsilon on both views, smallest feasible alpha, and endpoint fallback if the feasible set is empty.
4. Step 1C must map the actual selector implementation/source version to each historical and new evidence group. The current 1B tests intentionally did not certify selector correctness.

## 8. Step 1B conclusion

**Formula-to-recovered-implementation correspondence: PASS for all five families.**  
**Parameter-count correspondence: PASS for all five families.**  
**Current synthetic structural/endpoint tests: PASS for all five families.**  
**Exact historical runtime source certification: PARTIAL / NOT CLOSED**, principally because the original submission source package has no training code and the recovered SSF/LN code is from a later extension snapshot.

Step 1B is complete within these limits. It does not close Step 1C (selection rule), Step 1D (training/data protocol), Step 1E (figure/table evidence), Step 1F (chapter-level English), or Step 3 (full PDF submission check).
