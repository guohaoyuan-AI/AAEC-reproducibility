"""AAEC reference utilities."""
