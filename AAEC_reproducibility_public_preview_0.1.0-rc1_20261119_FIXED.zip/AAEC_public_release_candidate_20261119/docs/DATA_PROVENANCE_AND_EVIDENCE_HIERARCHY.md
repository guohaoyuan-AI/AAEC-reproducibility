# AAEC v3.1 — Data provenance and evidence hierarchy

**Author-confirmed project fact (2026-11-12):** The original AutoDL instance was released and all trained model weights/checkpoints from the earlier experiments were lost. The original manuscript, historical numerical records, candidate-level selection records, logs/configuration fragments, and other archived evidence remain available to varying degrees. The later models trained for the revision are newly trained models; they do not recover the original checkpoint bytes or reproduce the original optimization trajectory exactly.

## Binding rule

1. **Original-submission results are primary.** The original 15-epoch ViT-B/16 CIFAR-100 five-family results, original four-method full CIFAR-100-C cohort, and original cross-dataset/cross-scale records remain the basis of the manuscript's main scientific conclusions and primary tables.
2. **Post-submission training results are separate supplementary evidence.** C60 and Night7 use newly trained checkpoints after the original checkpoint loss. They are included only where they directly answer reviewer questions, with full protocol and provenance disclosure.
3. **No substitution or silent pooling.** A newly trained checkpoint must not replace an original result, even if the dataset, method, or numeric seed label is the same. Historical seed-42 values and newly trained seed-43/44 values must not be combined into a nominal three-seed mean unless the manuscript explicitly labels the cohort as mixed-source and justifies the statistic; the current revision does not do so. The later Adapter corruption cohort is not pooled into the original four-method CIFAR-100-C table.
4. **Same-checkpoint contrasts remain local.** Within a newly trained checkpoint, endpoint, fixed-$\alpha$, and AAEC states can be compared because they share that new checkpoint. Such a contrast does not make the new checkpoint equivalent to an original one.
5. **No causal inference from non-matched protocols.** C60 differs from the original 15-epoch protocol in duration, augmentation, learning-rate/training-policy choices, and post-result scope. It is not a matched continuation, not an augmentation-only ablation, and not a direct replication of the original model.
6. **Evidence grades remain explicit.** C60 has per-image prediction evidence and image-level paired bootstrap conditional on each new checkpoint, but only one newly trained seed per family. Night7 has logs/configurations/checkpoint identifiers plus an external AutoDL file inventory listing validation/test NPZs and 285 Adapter corruption-cell NPZs with remote SHA-256 and array-shape metadata. The raw NPZ bytes are absent from the current handoff, so no local independent per-image recomputation is claimed; report this as run-log plus external-inventory evidence. Neither evidence type is promoted to original-cohort evidence.
7. **Historical-data correction is distinct from retraining.** The correction from 9/15 to 11/15 clean-constraint violations is a re-audit of the original submission's recovered candidate-level records under the manuscript's existing either-view (OR) definition. It is not a result from newly trained models and does not replace original experimental outcomes.

## Where each evidence class may be used

| Evidence | Main manuscript | Supplement | Response letter |
|---|---|---|---|
| Original 15-epoch primary cohort | Primary tables, abstract, principal conclusions | Detailed records and diagnostics | Primary answer for R2-1 and context for R2-3 |
| C60 newly trained five-method seed-42 cohort | One short, clearly labelled pointer/summary only; no replacement table | Full results, paired bootstrap, 12-condition subset, validation resampling, five-/nine-point validation sensitivity and costs | Direct supplemental answer to R2-1/R2-2/R2-3 with limitations |
| Night7 newly trained ViT-S/16 and Adapter cohort | No pooled primary numbers; optional pointer only | Run-log plus external-inventory table and raw-prediction-byte limitation | Direct, qualified answer to R2-4 |
| Original 9/15-to-11/15 audit | Correct original table/figure/text | Candidate-level audit CSV and script | Explain numerical correction |

**Editorial test:** If a statement could be read as claiming that a new checkpoint reproduces, validates, or supersedes the lost original checkpoint, rewrite it. The main paper must remain a paper about the original AAEC experiment; the newly trained revision experiments are supporting evidence for reviewer questions, not a new primary study.


## 2026-11-13 incremental evidence update

- The R2-2 nine-point validation grid and single-view ablations are now complete on the five C60 seed-42 checkpoints. They are validation-only sensitivity analyses; the formal five-point grid remains unchanged, and no held-out result is inferred for newly introduced coefficients.
- Updated 100-draw validation-resampling counts and the new paired C60 bootstrap/McNemar outputs are included in the 13 November incremental evidence package.
- Night7 evidence has been upgraded from logs-only to run logs plus external file-inventory SHA/array-shape records. The seven-run raw prediction NPZ bytes remain unavailable in the handoff, so independent image-level reanalysis is still not claimed.
