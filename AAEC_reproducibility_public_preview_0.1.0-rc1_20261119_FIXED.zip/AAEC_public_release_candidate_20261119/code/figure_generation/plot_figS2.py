from plot_all_figures import plot_figS2
plot_figS2()
