from plot_all_figures import plot_fig5
plot_fig5()
