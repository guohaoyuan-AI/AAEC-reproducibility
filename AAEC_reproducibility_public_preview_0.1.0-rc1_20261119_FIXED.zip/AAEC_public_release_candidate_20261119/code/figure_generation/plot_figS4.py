from plot_all_figures import plot_figS4
plot_figS4()
