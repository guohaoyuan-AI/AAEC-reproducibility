from plot_all_figures import plot_fig1
plot_fig1()
