from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle
from matplotlib.lines import Line2D
from matplotlib.colors import TwoSlopeNorm, ListedColormap
from figure_style import apply_style, panel_label, save_figure, METHOD_ORDER

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DATA=ROOT/'data'/'figure_data'
FIG=ROOT/'figures'
FIG.mkdir(exist_ok=True)
apply_style()


def box(ax, xy, wh, text, fc='white', lw=1.0, fontsize=8.5, radius=0.03):
    x,y=xy; w,h=wh
    p=FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0.012,rounding_size={radius}',
                     transform=ax.transAxes, facecolor=fc, edgecolor='0.25', linewidth=lw)
    ax.add_patch(p); ax.text(x+w/2,y+h/2,text,transform=ax.transAxes,ha='center',va='center',fontsize=fontsize)
    return p

def arrow(ax, p1, p2, style='-|>', lw=1.2):
    ax.add_patch(FancyArrowPatch(p1,p2,transform=ax.transAxes,arrowstyle=style,
                                mutation_scale=10,linewidth=lw,color='0.25'))

def plot_fig1():
    fig,axs=plt.subplots(1,3,figsize=(13.2,4.4),gridspec_kw={'width_ratios':[1.0,1.35,1.0]})
    for ax in axs: ax.set_axis_off()
    # A
    ax=axs[0]; panel_label(ax,'A')
    ax.set_title('Conventional full-strength deployment',pad=10,fontweight='bold')
    ys=[0.78,0.57,0.36,0.15]; labels=['Pretrained model','Standard PEFT training','Final tuned endpoint $c_1$','Full-strength deployment']
    for y,t in zip(ys,labels): box(ax,(0.17,y),(0.66,0.12),t)
    for y1,y2 in zip(ys[:-1],ys[1:]): arrow(ax,(0.5,y1),(0.5,y2+0.12))
    ax.text(0.5,0.02,'Training endpoint is conventionally\ntreated as the deployment state.',transform=ax.transAxes,ha='center',va='bottom',fontsize=8)
    # B
    ax=axs[1]; panel_label(ax,'B'); ax.set_title('Validation-constrained AAEC selection',pad=10,fontweight='bold')
    xvals=np.linspace(0.12,0.88,5); labs=['$0.2$','$0.4$','$0.6$','$0.8$','$1.0$']
    ax.plot([xvals[0],xvals[-1]],[0.46,0.46],transform=ax.transAxes,clip_on=False)
    for x,l in zip(xvals,labs):
        ax.add_patch(Circle((x,0.46),0.022,transform=ax.transAxes,facecolor='white',edgecolor='C0',lw=1.4))
        ax.text(x,0.39,l,transform=ax.transAxes,ha='center',va='top',fontsize=8)
    box(ax,(0.05,0.76),(0.38,0.11),'Bicubic validation')
    box(ax,(0.57,0.76),(0.38,0.11),'Bilinear validation')
    box(ax,(0.20,0.59),(0.60,0.10),'Per-view grid best and\nretention threshold')
    arrow(ax,(0.24,0.76),(0.38,0.69)); arrow(ax,(0.76,0.76),(0.62,0.69))
    arrow(ax,(0.50,0.59),(0.50,0.50))
    box(ax,(0.26,0.13),(0.48,0.12),'Joint admissible set\n$\\rightarrow$ smallest $\\alpha$')
    arrow(ax,(0.50,0.43),(0.50,0.25))
    ax.text(0.5,0.03,'Anchor $c_0$ is a model state, not a candidate $\\alpha$\nMain tolerance: $\\epsilon=0.5$ pp; fallback: $\\alpha^\\star=1$',transform=ax.transAxes,ha='center',va='bottom',fontsize=7.5)
    # C
    ax=axs[2]; panel_label(ax,'C'); ax.set_title('Frozen deployment decision',pad=10,fontweight='bold')
    box(ax,(0.15,0.76),(0.70,0.11),'Same final checkpoint')
    box(ax,(0.23,0.58),(0.54,0.11),r'Frozen $\alpha^\star$')
    arrow(ax,(0.5,0.76),(0.5,0.69))
    box(ax,(0.09,0.34),(0.82,0.17),'Held-out evaluation\nNearest / corruptions / other datasets\n(not used for coefficient selection)',fontsize=8.0)
    arrow(ax,(0.5,0.58),(0.5,0.51))
    box(ax,(0.14,0.06),(0.72,0.16),'0 additional training epochs\n0 additional trainable parameters\n0 additional deployed modules',fontsize=7.4)
    fig.suptitle('AAEC workflow: validation-constrained calibration after PEFT training',fontsize=12,fontweight='bold',y=1.02)
    fig.tight_layout(w_pad=2.2)
    save_figure(fig,str(FIG/'fig1_aaec_overview'))


def path_panel(ax,title,left,right,formula,anchor,endpoint):
    ax.set_axis_off(); ax.set_title(title,fontweight='bold',pad=8)
    ax.plot([0.18,0.82],[0.52,0.52],transform=ax.transAxes,clip_on=False)
    for x,lab in [(0.18,left),(0.50,'$c_\\alpha$'),(0.82,right)]:
        ax.add_patch(Circle((x,0.52),0.035,transform=ax.transAxes,facecolor='white',edgecolor='C0',lw=1.4))
        ax.text(x,0.42,lab,transform=ax.transAxes,ha='center',va='top',fontsize=8)
    ax.text(0.5,0.73,formula,transform=ax.transAxes,ha='center',va='center',fontsize=10)
    ax.text(0.05,0.13,'Anchor: '+anchor,transform=ax.transAxes,ha='left',va='center',fontsize=7.6)
    ax.text(0.05,0.04,'Endpoint: '+endpoint,transform=ax.transAxes,ha='left',va='center',fontsize=7.6)


def plot_fig2():
    fig,axs=plt.subplots(2,3,figsize=(12.6,7.1))
    path_panel(axs[0,0],'LoRA weight delta','$W_0$','$W_0+\\Delta W$','$W_\\alpha=W_0+\\alpha\\Delta W_{\\mathrm{LoRA}}$','pretrained weight','trained low-rank update')
    path_panel(axs[0,1],'DoRA effective weight','$W_0$','$W_{\\mathrm{DoRA}}$','$W_\\alpha=W_0+\\alpha(W_{\\mathrm{DoRA}}-W_0)$','pretrained weight','complete effective weight')
    ax=axs[0,2]; ax.set_axis_off(); ax.set_title('Unified method-native path',fontweight='bold',pad=8)
    box(ax,(0.12,0.58),(0.76,0.18),'$c_\\alpha=c_0+\\alpha(c_1-c_0)$',fontsize=12)
    box(ax,(0.10,0.30),(0.34,0.13),'$c_0$\nmethod-native anchor')
    box(ax,(0.56,0.30),(0.34,0.13),'$c_1$\nfinal tuned endpoint')
    arrow(ax,(0.27,0.43),(0.38,0.58)); arrow(ax,(0.73,0.43),(0.62,0.58))
    ax.text(0.5,0.10,'Common decision rule;\nobject-specific implementation',transform=ax.transAxes,ha='center',fontsize=8.5)
    path_panel(axs[1,0],'Adapter residual response','$h_{\\mathrm{block}}$','$h_{\\mathrm{block}}+A_{\\mathrm{tuned}}(h_{\\mathrm{block}})$','$h_{\\mathrm{out}}=h_{\\mathrm{block}}+\\alpha A_{\\mathrm{tuned}}(h_{\\mathrm{block}})$','no-adapter residual path','trained adapter response')
    path_panel(axs[1,1],'SSF scale-shift','$(1,0)$','$(\\gamma_1,\\beta_1)$','$\\gamma_\\alpha=1+\\alpha(\\gamma_1-1),\\;\\beta_\\alpha=\\alpha\\beta_1$','identity modulation','trained scale and shift')
    path_panel(axs[1,2],'LayerNorm affine','$\\theta_{\\mathrm{LN},0}$','$\\theta_{\\mathrm{LN},1}$','$\\theta_{\\mathrm{LN},\\alpha}=\\theta_{\\mathrm{LN},0}+\\alpha(\\theta_{\\mathrm{LN},1}-\\theta_{\\mathrm{LN},0})$','pretrained affine','tuned affine')
    for i,ax in enumerate(axs.ravel()): panel_label(ax,chr(65+i))
    fig.suptitle('Five PEFT families share an anchor-to-endpoint decision without sharing one parameterization',fontsize=12,fontweight='bold',y=1.01)
    fig.tight_layout(h_pad=2.3,w_pad=1.8)
    save_figure(fig,str(FIG/'fig2_five_family_instantiations'))


def plot_fig3():
    df=pd.read_csv(DATA/'fig3_cifar100_results.csv')
    methods=METHOD_ORDER; y=np.arange(len(methods))[::-1]
    fig,axs=plt.subplots(1,2,figsize=(12.2,4.7),gridspec_kw={'width_ratios':[1.25,1.0]})
    ax=axs[0]; panel_label(ax,'A')
    for yi,m in zip(y,methods):
        z=df[df.method==m]
        ep=z[z.state=='Endpoint']; aa=z[z.state=='AAEC']
        mep=ep.nearest_acc_pct.mean(); maa=aa.nearest_acc_pct.mean()
        ax.plot([mep,maa],[yi,yi],color='0.55',lw=1.8,zorder=1)
        ax.scatter(ep.nearest_acc_pct, np.full(len(ep),yi)+np.array([-0.08,0,0.08])[:len(ep)],facecolors='none',edgecolors='C0',s=30,zorder=3)
        ax.scatter(aa.nearest_acc_pct, np.full(len(aa),yi)+np.array([-0.08,0,0.08])[:len(aa)],color='C1',s=30,zorder=3)
        ax.scatter([mep],[yi],facecolors='none',edgecolors='C0',s=75,linewidths=1.8,zorder=4)
        ax.scatter([maa],[yi],color='C1',s=75,zorder=4)
    ax.set_yticks(y,methods); ax.set_xlabel('Nearest test accuracy (%)'); ax.set_title('Same-checkpoint endpoint-to-AAEC shift')
    ax.legend(handles=[Line2D([0],[0],marker='o',markerfacecolor='none',markeredgecolor='C0',linestyle='None',label='Endpoint'),
                       Line2D([0],[0],marker='o',color='C1',linestyle='None',label='AAEC')],loc='lower right',frameon=False)
    ax=axs[1]; panel_label(ax,'B')
    for yi,m in zip(y,methods):
        z=df[df.method==m].pivot(index='seed',columns='state',values='nearest_acc_pct')
        gains=(z['AAEC']-z['Endpoint']).values
        mean=gains.mean(); sd=gains.std(ddof=1)
        ax.errorbar(mean,yi,xerr=sd,fmt='o',capsize=3,color='C1',zorder=4)
        ax.scatter(gains,np.full(len(gains),yi)+np.array([-0.08,0,0.08])[:len(gains)],facecolors='none',edgecolors='C1',s=28,zorder=3)
        ax.text(mean+sd+0.25,yi,f'{mean:.2f}',va='center',fontsize=8)
    ax.axvline(0,color='0.3',lw=1)
    ax.set_yticks(y,methods); ax.set_xlabel('Nearest gain (pp)'); ax.set_title('Three-seed gain (mean ± sample SD)')
    fig.suptitle('Same-checkpoint AAEC effects across five PEFT families on ViT-B/16 CIFAR-100',fontsize=11.6,fontweight='bold',y=1.01)
    fig.tight_layout(w_pad=2.2)
    save_figure(fig,str(FIG/'fig3_cifar100_five_method_results'))


def plot_fig4():
    df=pd.read_csv(DATA/'fig4_policy_comparison.csv')
    labels=['Fixed 0.8','Fixed 0.6','Clean argmax','AAEC 0.5 pp','AAEC 0.3 pp','Nearest oracle']
    y=np.arange(len(labels))[::-1]
    fig,axs=plt.subplots(1,2,figsize=(11.7,4.7),gridspec_kw={'width_ratios':[1.35,0.85]})
    ax=axs[0]; panel_label(ax,'A')
    ax.barh(y,df['Mean Nearest Gain (pp)'],xerr=df['Sample SD across cells (pp)'],capsize=3,alpha=0.8)
    for yi,val in zip(y,df['Mean Nearest Gain (pp)']): ax.text(val+0.25,yi,f'{val:.2f}',va='center',fontsize=8)
    ax.set_yticks(y,labels); ax.set_xlabel('Mean held-out Nearest gain (pp)'); ax.set_title('Held-out gain')
    ax=axs[1]; panel_label(ax,'B')
    ax.barh(y,df['Clean Violations'],alpha=0.8)
    for yi,val in zip(y,df['Clean Violations']): ax.text(val+0.15,yi,f'{int(val)}/15',va='center',fontsize=8)
    ax.set_yticks(y,[]); ax.set_xlim(0,10.5); ax.set_xlabel('Clean-constraint violations'); ax.set_title('Validation safety')
    fig.suptitle('Held-out gain and clean-safety trade-offs across coefficient-selection rules',fontsize=11.6,fontweight='bold',y=1.01)
    fig.tight_layout(w_pad=2.2)
    save_figure(fig,str(FIG/'fig4_policy_clean_safety_tradeoff'))


def plot_fig5():
    sev=pd.read_csv(DATA/'fig5_severity.csv'); cor=pd.read_csv(DATA/'fig5_corruption_matrix.csv')
    methods=METHOD_ORDER[:2]+METHOD_ORDER[3:]
    order=['gaussian_noise','shot_noise','impulse_noise','speckle_noise',
           'defocus_blur','glass_blur','motion_blur','zoom_blur','gaussian_blur',
           'snow','frost','fog','brightness',
           'contrast','elastic_transform','pixelate','jpeg_compression','saturate','spatter']
    fig=plt.figure(figsize=(14.3,6.3)); gs=fig.add_gridspec(1,2,width_ratios=[0.85,2.15],wspace=0.20)
    ax=fig.add_subplot(gs[0,0]); panel_label(ax,'A')
    for m in methods:
        z=sev[sev.method==m].sort_values('severity')
        ax.plot(z.severity,z.gain_pp,marker='o',label=m)
    ax.axhline(0,color='0.3',lw=1); ax.set_xticks([1,2,3,4,5]); ax.set_xlabel('Corruption severity'); ax.set_ylabel('AAEC - endpoint accuracy (pp)')
    ax.set_title('Aggregate severity trend'); ax.legend(frameon=False,ncol=2,loc='upper left')
    ax=fig.add_subplot(gs[0,1]); panel_label(ax,'B')
    p=cor.pivot(index='method',columns='corruption',values='gain_pp').reindex(index=methods,columns=order)
    vmax=max(abs(np.nanmin(p.values)),abs(np.nanmax(p.values)))
    im=ax.imshow(p.values,aspect='auto',cmap='coolwarm',norm=TwoSlopeNorm(vcenter=0,vmin=-vmax,vmax=vmax))
    ax.set_yticks(np.arange(len(methods)),methods); ax.set_xticks(np.arange(len(order)),[x.replace('_',' ') for x in order],rotation=58,ha='right')
    ax.set_title('Corruption-specific mean gain (pp)')
    for boundary in [3.5,8.5,12.5]: ax.axvline(boundary,color='white',lw=2.2)
    for i in range(p.shape[0]):
        for j in range(p.shape[1]):
            v=p.iloc[i,j]
            ax.text(j,i,f'{v:.1f}',ha='center',va='center',fontsize=5.7,color='black' if abs(v)<vmax*0.55 else 'white')
    cb=fig.colorbar(im,ax=ax,fraction=0.027,pad=0.02); cb.set_label('Gain (pp)')
    ax.text(1.5,-1.1,'Noise',ha='center',fontsize=8,fontweight='bold')
    ax.text(6.0,-1.1,'Blur',ha='center',fontsize=8,fontweight='bold')
    ax.text(10.5,-1.1,'Weather',ha='center',fontsize=8,fontweight='bold')
    ax.text(15.5,-1.1,'Digital / other',ha='center',fontsize=8,fontweight='bold')
    fig.suptitle('Aggregate severity trends and corruption-specific heterogeneity on CIFAR-100-C',fontsize=11.7,fontweight='bold',y=0.99)
    fig.subplots_adjust(top=0.86,bottom=0.28,left=0.07,right=0.98)
    save_figure(fig,str(FIG/'fig5_cifar100c_robustness'))


def plot_fig6():
    df=pd.read_csv(DATA/'fig6_evidence_status.csv')
    methods=['LoRA','DoRA','Adapter','SSF','LayerNorm tuning']; settings=['ViT-B C100','ViT-B C100-C','Tiny-ImageNet','ImageNet-100','ViT-S C100','ViT-S C100-C']
    styles={
        'Primary, 3 seeds': {'facecolor':'0.25','hatch':'','text':'white'},
        'Additional, 3 seeds': {'facecolor':'0.62','hatch':'///','text':'black'},
        'Single seed': {'facecolor':'0.82','hatch':'..','text':'black'},
        'Mixed-source, 3 seeds': {'facecolor':'0.46','hatch':'xx','text':'white'},
        'Later log+inventory, 3 seeds': {'facecolor':'0.86','hatch':'++','text':'black'},
        'Not evaluated': {'facecolor':'0.96','hatch':'','text':'black'},
    }
    fig,ax=plt.subplots(figsize=(11.3,4.8))
    for i,m in enumerate(methods):
        for j,s in enumerate(settings):
            st=df[(df.method==m)&(df.setting==s)].status.iloc[0]
            sty=styles[st]
            ax.add_patch(Rectangle((j-0.5,i-0.5),1,1,facecolor=sty['facecolor'],edgecolor='0.45',linewidth=0.6,hatch=sty['hatch']))
            txt={'Not evaluated':'--','Single seed':'1 seed','Additional, 3 seeds':'additional\n3 seeds','Primary, 3 seeds':'primary\n3 seeds','Mixed-source, 3 seeds':'3 seeds\nmixed sources','Later log+inventory, 3 seeds':'3 seeds\nlog + inventory'}[st]
            ax.text(j,i,txt,ha='center',va='center',fontsize=7.1,color=sty['text'],fontweight='bold' if st in ['Mixed-source, 3 seeds','Primary, 3 seeds'] else 'normal')
    ax.set_xlim(-0.5,len(settings)-0.5); ax.set_ylim(len(methods)-0.5,-0.5)
    ax.set_xticks(np.arange(len(settings)),settings,rotation=25,ha='right'); ax.set_yticks(np.arange(len(methods)),methods)
    ax.set_title('Cross-dataset and cross-scale evaluation coverage',fontweight='bold')
    ordered=['Primary, 3 seeds','Additional, 3 seeds','Single seed','Mixed-source, 3 seeds','Later log+inventory, 3 seeds','Not evaluated']
    handles=[Rectangle((0,0),1,1,facecolor=styles[s]['facecolor'],edgecolor='0.3',hatch=styles[s]['hatch'],label=s) for s in ordered]
    ax.legend(handles=handles,bbox_to_anchor=(0.5,-0.28),loc='upper center',ncol=3,frameon=False,fontsize=7.5)
    ax.set_xlabel('Setting'); ax.set_ylabel('PEFT family')
    fig.tight_layout()
    save_figure(fig,str(FIG/'fig6_evidence_boundary_map'))


def plot_figS1():
    df=pd.read_csv(DATA/'figS1_alpha_selection_map.csv')
    methods=METHOD_ORDER; seeds=[42,43,44]
    fig,axs=plt.subplots(1,2,figsize=(9.6,4.3),sharey=True)
    for ax,tol,label in zip(axs,['0.5 pp','0.3 pp'],['A','B']):
        panel_label(ax,label)
        z=df[df.tolerance==tol].pivot(index='method',columns='seed',values='alpha').reindex(index=methods,columns=seeds)
        im=ax.imshow(z.values,aspect='auto',cmap='viridis',vmin=0.2,vmax=1.0)
        ax.set_xticks(range(3),seeds); ax.set_yticks(range(5),methods); ax.set_xlabel('Seed'); ax.set_title(f'Clean-retention tolerance: $\\epsilon={tol.split()[0]}$ pp')
        for i in range(5):
            for j in range(3): ax.text(j,i,f'{z.iloc[i,j]:.1f}',ha='center',va='center',color='white' if z.iloc[i,j]<0.55 or z.iloc[i,j]>0.9 else 'black',fontweight='bold')
    cb=fig.colorbar(im,ax=axs.ravel().tolist(),fraction=0.025,pad=0.03); cb.set_label('Selected $\\alpha$')
    fig.suptitle('AAEC coefficient selection changes across families, seeds, and clean-retention tolerance',fontsize=11.4,fontweight='bold',y=1.02)
    fig.subplots_adjust(wspace=0.20,right=0.90,top=0.84,bottom=0.14)
    save_figure(fig,str(FIG/'figS1_alpha_selection_map'))


def plot_figS2():
    df=pd.read_csv(DATA/'figS2_validation_plateau_examples.csv')
    examples=df.example.unique()
    fig,axs=plt.subplots(1,3,figsize=(13.0,4.2),sharey=False)
    for ax,ex,label in zip(axs,examples,['A','B','C']):
        panel_label(ax,label); z=df[df.example==ex].sort_values('alpha'); selected=float(z.selected_alpha.iloc[0]); fallback=int(z.fallback.iloc[0])
        ax.plot(z.alpha,z.val_bicubic_acc*100,marker='o',label='Bicubic validation')
        ax.plot(z.alpha,z.val_bilinear_acc*100,marker='s',label='Bilinear validation')
        for col,ls in [('val_bicubic_acc','--'),('val_bilinear_acc',':')]:
            threshold=(z[col].max()-0.005)*100
            ax.axhline(threshold,ls=ls,lw=1,color='0.45')
        ax.axvline(selected,color='C3',lw=1.4)
        ax.scatter([selected],[np.interp(selected,z.alpha,z.val_bicubic_acc*100)],marker='*',s=100,color='C3',zorder=5)
        ax.set_xticks([0.2,0.4,0.6,0.8,1.0]); ax.set_xlabel('$\\alpha$'); ax.set_ylabel('Validation accuracy (%)'); ax.set_title(ex)
        ax.text(0.04,0.96,('Empty-set fallback' if fallback else ('Admissible endpoint $\\alpha=1.0$' if selected==1.0 else f'Selected $\\alpha={selected:.1f}$')),transform=ax.transAxes,ha='left',va='top',fontsize=8,fontweight='bold',bbox=dict(facecolor='white',edgecolor='none',alpha=0.82,pad=1.5))
        if ax is axs[0]: ax.legend(frameon=False,loc='lower right')
    fig.suptitle('Representative validation plateaus under the smallest jointly admissible rule',fontsize=11.4,fontweight='bold',y=1.01)
    fig.tight_layout(w_pad=1.6)
    save_figure(fig,str(FIG/'figS2_validation_plateau_examples'))


def plot_figS3():
    df=pd.read_csv(DATA/'figS3_representation_diagnostics.csv')
    fig,axs=plt.subplots(1,2,figsize=(10.8,4.4))
    for ax,prot,label in zip(axs,['LoRA/DoRA WP5','Adapter/SSF/LN legacy'],['A','B']):
        panel_label(ax,label); z=df[df.protocol==prot]; methods=list(dict.fromkeys(z.method)); x=np.arange(len(methods)); width=0.34
        for k,(metric,offset) in enumerate([('CKA increase',-width/2),('SpecDist reduction',width/2)]):
            q=z[z.metric==metric].set_index('method').reindex(methods)
            y=q.value.values; err=q.sd.values.astype(float) if q.sd.notna().any() else None
            ax.bar(x+offset,y,width,label=metric,yerr=err,capsize=3 if err is not None else 0)
        ax.axhline(0,color='0.3',lw=1); ax.set_xticks(x,methods); ax.set_ylabel('Endpoint-to-selected change'); ax.set_title(prot)
        ax.legend(frameon=False)
    fig.suptitle('Representation-proximity diagnostics within two separate protocols',fontsize=11.2,fontweight='bold',y=1.01)
    fig.text(0.5,0.01,'Absolute values are not used for cross-protocol method ranking; the diagnostics are associative, not causal.',ha='center',fontsize=8)
    fig.tight_layout(rect=[0,0.05,1,0.95],w_pad=2)
    save_figure(fig,str(FIG/'figS3_representation_diagnostics'))


def plot_figS4():
    df=pd.read_csv(DATA/'figS4_merge_deployment.csv'); name_map={'lora':'LoRA','dora':'DoRA','LORA':'LoRA','DORA':'DoRA','LoRA':'LoRA','DoRA':'DoRA'}; methods=[name_map.get(str(m),str(m)) for m in df.Method]; x=np.arange(len(methods)); width=0.24
    fig,axs=plt.subplots(1,3,figsize=(13.0,4.3))
    panel_label(axs[0],'A');
    vals=[df['Endpoint Throughput (images/s)'],df['Wrapped Throughput (images/s)'],df['Merged Throughput (images/s)']]
    for i,(v,l) in enumerate(zip(vals,['Endpoint','Wrapped','Merged'])): axs[0].bar(x+(i-1)*width,v,width,label=l)
    axs[0].set_xticks(x,methods); axs[0].set_ylabel('Throughput (images/s)'); axs[0].set_title('Throughput'); axs[0].legend(frameon=False,loc='upper center',bbox_to_anchor=(0.5,1.22),ncol=3,fontsize=7)
    panel_label(axs[1],'B'); vals=[df['Endpoint Single Latency (ms)'],df['Wrapped Single Latency (ms)'],df['Merged Single Latency (ms)']]
    for i,(v,l) in enumerate(zip(vals,['Endpoint','Wrapped','Merged'])): axs[1].bar(x+(i-1)*width,v,width,label=l)
    axs[1].set_xticks(x,methods); axs[1].set_ylabel('Single-sample latency (ms)'); axs[1].set_title('Latency')
    panel_label(axs[2],'C'); vals=[df['Endpoint Peak Mem (MB)'],df['Merged Peak Mem (MB)']]
    for i,(v,l) in enumerate(zip(vals,['Endpoint','Merged'])): axs[2].bar(x+(i-0.5)*width,v,width,label=l)
    axs[2].set_xticks(x,methods); axs[2].set_ylabel('Peak memory (MB)'); axs[2].set_title('Peak memory and merge equivalence')
    axs[2].set_ylim(0,1050)
    for i,r in df.iterrows(): axs[2].text(i, 1015,f"max |Δlogit| = {r['Max |Δlogit|']:.2e}",ha='center',va='top',fontsize=6.8)
    fig.suptitle('LoRA and DoRA deployment measurements under the common WP6 protocol',fontsize=11.4,fontweight='bold',y=1.01)
    fig.tight_layout(w_pad=2,rect=[0,0,1,0.95])
    save_figure(fig,str(FIG/'figS4_merge_deployment'))

if __name__=='__main__':
    plot_fig1(); plot_fig2(); plot_fig3(); plot_fig4(); plot_fig5(); plot_fig6(); plot_figS1(); plot_figS2(); plot_figS3(); plot_figS4()
    print('Generated',len(list(FIG.glob('*.pdf'))),'PDF figures and',len(list(FIG.glob('*.png'))),'PNG figures')
