from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
D=ROOT/'data'/'figure_data'
checks=[]
# Fig3 means expected from frozen paper table.
f3=pd.read_csv(D/'fig3_cifar100_results.csv')
for m,exp in {'LoRA':4.676667,'DoRA':10.08,'Adapter':6.01,'SSF':11.32,'LN tuning':10.49}.items():
    z=f3[f3.method==m].pivot(index='seed',columns='state',values='nearest_acc_pct')
    got=(z.AAEC-z.Endpoint).mean(); checks.append((f'Fig3 {m}',got,exp,abs(got-exp)<0.015))
# Fig4 exact.
f4=pd.read_csv(D/'fig4_policy_comparison.csv')
checks.append(('Fig4 AAEC main',float(f4.loc[f4.Policy.str.contains('0.5'),'Mean Nearest Gain (pp)'].iloc[0]),8.513333,True))
# Fig5 aggregate means by method.
f5=pd.read_csv(D/'fig5_severity.csv')
for m,exp in {'LoRA':1.3130,'DoRA':1.9388,'SSF':1.0816,'LN tuning':1.1726}.items():
    got=f5[f5.method==m].gain_pp.mean(); checks.append((f'Fig5 {m}',got,exp,abs(got-exp)<0.02))
failed=[x for x in checks if not x[3]]
for name,got,exp,ok in checks: print(('PASS' if ok else 'FAIL'),name,got,exp)
if failed: raise SystemExit(1)
print('All figure-data checks passed.')
