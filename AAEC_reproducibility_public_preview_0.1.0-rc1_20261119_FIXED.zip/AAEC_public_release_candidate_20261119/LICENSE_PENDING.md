# License status

The author has selected the dual-license policy and the public preview now
contains `LICENSE` (MIT), `DATA_LICENSE` (CC BY 4.0), and `LICENSE_SCOPE.md`.
Recovered third-party/foundation runtime source snapshots have been excluded
from this preview because their complete upstream license/notice provenance
has not yet been established. No third-party dataset or pretrained weights
are redistributed.
