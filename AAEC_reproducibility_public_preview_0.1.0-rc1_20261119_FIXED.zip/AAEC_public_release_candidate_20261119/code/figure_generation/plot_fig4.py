from plot_all_figures import plot_fig4
plot_fig4()
