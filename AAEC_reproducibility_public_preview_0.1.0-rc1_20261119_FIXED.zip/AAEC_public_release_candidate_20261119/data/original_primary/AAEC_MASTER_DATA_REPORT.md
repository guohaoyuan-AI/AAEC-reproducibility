# AAEC WP8-A Master Data Freeze Report

Decision: `WP8A_MASTER_DATA_FREEZE_PASS`

## 完成内容

- Master long records: 3910
- Seed-level summary rows: 20
- Method-level summary rows: 70
- Alpha selection registry rows: 38
- Protocol registry rows: 7
- Frozen claims: 7/7
- Cross-table audit checks: 54
- Cross-table conflicts: 0
- Formal Nearest-selection leakage flags: 0
- Fraction-unit violations: 0

## 数据边界

1. CIFAR-100：LoRA 与 DoRA 均为三种子强阳性。
2. CIFAR-100-C：LoRA 与 DoRA 的 mean corruption accuracy 均为三种子正向。
3. Tiny-ImageNet：DoRA 为三种子强阳性；LoRA 仅为弱阳性/边界。
4. ImageNet-100：仅保留 single-seed low-headroom pilot，不构成大规模泛化证据。
5. CKA/SpecDist：支持 selected state 更接近 frozen anchor 的关联解释，不证明因果机制或高频抑制。
6. Efficiency：AAEC 增加 0 个训练参数与 0 个训练 epoch；wrapped runtime overhead 不是字面意义上的 0，merged deployment 移除 wrappers。

## 后续使用规则

- 论文表格、图和正文数字必须从本包派生。
- Accuracy 的底层单位固定为 fraction；展示时才乘以 100。
- Gain/Drop/Reduction 固定使用 percentage points。
- 任何 ImageNet-100 数字必须带 single-seed pilot / boundary 限定。
- 不得删除或隐藏 Tiny-ImageNet LoRA seed44 和 DoRA elastic-transform 负结果。
- 不得把 Nearest oracle 写成部署策略。
