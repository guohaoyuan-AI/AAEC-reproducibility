# Night7 Adapter extension

This folder contains log-derived summaries for Adapter seeds 42/43/44,
19 corruption types x 5 severities, plus external inventory hashes and
array-shape metadata. The underlying 285 corruption NPZ byte files are not
present in this release. Do not describe these summaries as independently
recomputed from local per-image prediction arrays.
