from pathlib import Path
import csv, hashlib, sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
FORBIDDEN={'.pt','.pth','.ckpt','.safetensors','.onnx','.engine'}
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
errors=[]
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    if p.suffix.lower() in FORBIDDEN: errors.append(f'forbidden weight file: {p.relative_to(ROOT)}')
    if p.suffix.lower()=='.npz':
        try:
            with np.load(p,allow_pickle=False) as z:
                keys=set(z.files)
                if 'image_ids' not in keys: errors.append(f'NPZ missing image_ids: {p.relative_to(ROOT)}')
                if not any(('pred' in k.lower()) or k=='predictions' for k in keys):
                    errors.append(f'NPZ does not look like a prediction archive: {p.relative_to(ROOT)}')
                for k in z.files:
                    if z[k].dtype.kind=='O': errors.append(f'object array not allowed: {p.relative_to(ROOT)}::{k}')
        except Exception as e: errors.append(f'cannot inspect NPZ {p.relative_to(ROOT)}: {e}')
    if p.suffix.lower()=='.npy':
        try:
            a=np.load(p,allow_pickle=False)
            if a.dtype.kind not in 'iu' or a.ndim!=1:
                errors.append(f'NPY is not a 1-D integer index vector: {p.relative_to(ROOT)}')
        except Exception as e: errors.append(f'cannot inspect NPY {p.relative_to(ROOT)}: {e}')
manifest=ROOT/'SHA256SUMS.csv'
with manifest.open(encoding='utf-8') as f:
    for row in csv.DictReader(f):
        p=ROOT/row['relative_path']
        if not p.is_file(): errors.append(f'missing: {row["relative_path"]}'); continue
        if sha(p)!=row['sha256']: errors.append(f'hash mismatch: {row["relative_path"]}')
if errors:
    print('RELEASE CHECK FAILED')
    print('\n'.join(errors)); sys.exit(1)
print('RELEASE CHECK PASS: no model-weight files; prediction/index arrays inspected; all manifest hashes match.')
