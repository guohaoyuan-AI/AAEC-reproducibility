from plot_all_figures import plot_fig3
plot_fig3()
