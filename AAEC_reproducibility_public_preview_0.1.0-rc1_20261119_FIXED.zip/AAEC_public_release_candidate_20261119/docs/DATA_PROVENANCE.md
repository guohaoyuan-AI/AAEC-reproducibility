# Data provenance and evidence classes

## Original primary cohort

`data/original_primary/` is based on the frozen WP8-A master-data package
generated 2026-07-28. Its manifest records 3,910 long-format records,
20 seed-level rows, 70 method-level rows, 38 alpha-selection records,
seven protocol records, and 54 cross-table checks with zero failures.
Accuracy values are stored as fractions; gains/drops are percentage points.

The original candidate-level records are reconstructed from retained
aggregate records. They are not per-image prediction archives. The old
trained checkpoints are not included and were reported lost.

## C60 revision cohort

`data/revision_c60/` contains post-submission seed-42 supplementary
experiments. The B arm used 15 epochs and the C arm used 60 epochs under
the revision protocol. Five PEFT families are represented. Raw validation,
held-out test, and predeclared corruption prediction arrays are included
where present. These results are separate from the original primary
cohort and must not be pooled with it.

## Night7 Adapter extension

`data/revision_night7/` contains three Adapter training-seed summaries,
per-corruption summaries, and external inventory hashes/array shapes for
the 285 corruption conditions. The raw Night7 NPZ bytes are not present
in this release. This evidence class is therefore run-log plus
external-inventory evidence, not independent local per-image reproduction.

## Dataset redistribution

Benchmark images are not included. Users must obtain each dataset from its
official source and comply with its license/terms. The split index arrays
in `data/splits/` contain only integer sample indices, not images.
