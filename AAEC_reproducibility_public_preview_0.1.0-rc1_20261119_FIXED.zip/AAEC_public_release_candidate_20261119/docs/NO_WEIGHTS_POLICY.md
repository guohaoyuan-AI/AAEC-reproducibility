# No-weights publication policy

This repository excludes all pretrained and fine-tuned model weights,
checkpoints, optimizer states, and serialized model parameters.

Allowed artifacts include: source code, YAML/JSON configurations,
experiment manifests, SHA-256 metadata, CSV result tables, split indices,
and prediction arrays whose contents are sample IDs, labels, and class
predictions (not images or model parameters).

The release verifier rejects common model-weight extensions. Review any
new `.npz`, `.npy`, `.bin`, or archive before adding it; extension alone
does not establish that a file is safe to publish.
