from plot_all_figures import plot_fig2
plot_fig2()
