from __future__ import annotations
import matplotlib as mpl
import matplotlib.pyplot as plt

METHOD_LABELS = {
    'lora': 'LoRA', 'dora': 'DoRA', 'adapter': 'Adapter',
    'ssf': 'SSF', 'ln_tuning': 'LN tuning', 'LN tuning': 'LN tuning',
    'LORA': 'LoRA', 'DORA': 'DoRA', 'Adapter': 'Adapter', 'SSF': 'SSF'
}
METHOD_ORDER = ['LoRA', 'DoRA', 'Adapter', 'SSF', 'LN tuning']


def apply_style():
    mpl.rcParams.update({
        'font.family': 'DejaVu Sans',
        'font.size': 9,
        'axes.titlesize': 10.5,
        'axes.labelsize': 9.5,
        'xtick.labelsize': 8.2,
        'ytick.labelsize': 8.5,
        'legend.fontsize': 8.2,
        'figure.dpi': 150,
        'savefig.dpi': 600,
        'pdf.fonttype': 42,
        'ps.fonttype': 42,
        'axes.spines.top': False,
        'axes.spines.right': False,
        'axes.grid': True,
        'grid.alpha': 0.22,
        'grid.linewidth': 0.6,
        'lines.linewidth': 1.6,
        'lines.markersize': 5.5,
    })


def panel_label(ax, label):
    ax.text(-0.08, 1.04, label, transform=ax.transAxes, fontsize=11,
            fontweight='bold', va='bottom', ha='left')


def save_figure(fig, basepath):
    fig.savefig(basepath + '.pdf', bbox_inches='tight')
    fig.savefig(basepath + '.png', dpi=600, bbox_inches='tight')
    plt.close(fig)
